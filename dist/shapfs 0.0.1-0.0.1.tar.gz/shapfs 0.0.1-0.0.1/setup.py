from setuptools import setup, find_packages

setup(
    name='shapfs 0.0.1',
    version='0.0.1',
    author='Jianyang Hu',
    author_email='meegohjy@gmail.com',
    description='Shapley value is used for feature selection',
    packages=find_packages(),

)